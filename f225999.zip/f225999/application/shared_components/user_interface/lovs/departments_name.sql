prompt --application/shared_components/user_interface/lovs/departments_name
begin
--   Manifest
--     DEPARTMENTS.NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.4'
,p_default_workspace_id=>110605810036407028651
,p_default_application_id=>225999
,p_default_id_offset=>110732012177564672431
,p_default_owner=>'WKSP_AJBCASTOR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(149156350376403040801)
,p_lov_name=>'DEPARTMENTS.NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'DEPARTMENTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
