prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 225999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.4'
,p_default_workspace_id=>110605810036407028651
,p_default_application_id=>225999
,p_default_id_offset=>110732012177564672431
,p_default_owner=>'WKSP_AJBCASTOR'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(149155318114634039999)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>15530003472034
);
wwv_flow_imp.component_end;
end;
/
